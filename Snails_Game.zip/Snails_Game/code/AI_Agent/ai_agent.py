import arcade
import random
cross = arcade.load_texture("images/11-removebg-preview.png")
circle = arcade.load_texture("images/12-removebg-preview.png")
splash1 = arcade.load_texture("images/sp1.png")
splash2 = arcade.load_texture("images/download.png")
display = arcade.load_texture("images/12.png")
winner = arcade.load_texture("images/winner.png")
lose = arcade.load_texture("images/lose.png")


class Game(arcade.View):
    def __init__(self):
        super().__init__()
        self.board = [[0 for i in range(10)] for j in range(10)]
        self.board[0][9]=20
        self.board[9][0]=10
        self.win = "0"
        self.state = "GameMenu"
        self.turn = "Human"
        self.score_1 = 0
        self.score_2 = 0
        self.stop = 0

    def on_key_press(self, key, modifiers):
        if self.state == "GameMenu":
            if key == arcade.key.ENTER:
                self.state = "GameOn"
                self.turn="Human"

        if self.state == "GameOver":
            if key == arcade.key.ENTER:
                # self.state = "GameMenu"
                # self.turn="Human"
                game_view = Game()
                window.show_view(game_view)



    def on_show(self):
        arcade.set_background_color(arcade.color.BLACK)

    def on_draw(self):
        arcade.start_render()



        if self.state == "GameMenu":
            arcade.draw_text("Snail Game", 400, 450,
                             arcade.color.WHITE, font_size=60, anchor_x="center")
            arcade.draw_text("Game Rules:", 150, 400,
                             arcade.color.WHITE, font_size=30, anchor_x="center")
            arcade.draw_text("-->  Human will take 1st turn", 200, 350,
                             arcade.color.WHITE, font_size=15, anchor_x="left")
            arcade.draw_text("-->  Score more than 50 to win", 200, 300,
                             arcade.color.WHITE, font_size=15, anchor_x="left")
            arcade.draw_text("-->  Illigal move will cause in loss if turn", 200, 250,
                             arcade.color.WHITE, font_size=15, anchor_x="left")
            arcade.draw_text("Press  'ENTER' To Start Game",
                             400, 150, arcade.color.WHITE, font_size=30, anchor_x="center")



        elif self.state == "GameOn":
            self.shape_list = arcade.ShapeElementList()
            # updating scores on screen
            ouput1 = f"Score: {self.score_1}"
            ouput2 = f"Score: {self.score_2}"
            # drawing scores for both players
            arcade.draw_text(ouput1,
                             630, 160, arcade.color.WHITE, font_size=26)
            arcade.draw_text(ouput2,
                             630, 390, arcade.color.WHITE, font_size=26)

            # drawing for Player 1
            arcade.draw_text("AI Agent ",
                             640, 540, arcade.color.WHITE, font_size=30)
            arcade.draw_lrwh_rectangle_textured(640, 440, 100, 80, display)
            arcade.draw_rectangle_outline(700, 490, 178, 200,
                                          arcade.color.GREEN, 4)
            # drawing for Player 2
            arcade.draw_rectangle_outline(700, 260, 178, 210,
                                          arcade.color.GREEN, 4)
            arcade.draw_text("Human",
                             640, 310, arcade.color.WHITE, font_size=30)
            arcade.draw_lrwh_rectangle_textured(640, 200, 100, 100, circle)
            # drawing  turn
            arcade.draw_rectangle_outline(700, 70, 178, 115,
                                          arcade.color.GREEN, 4)

            arcade.draw_text("TURN",
                             655, 90, arcade.color.BABY_BLUE, font_size=25)
            #displaying turn of player                 
            if self.turn == "Human":
                arcade.draw_text("Human",
                                 645, 40, arcade.color.RASPBERRY, font_size=24)
            elif self.turn == "bot":
                arcade.draw_text("AI Agent",
                                 645, 40, arcade.color.RAJAH, font_size=24)
            #drawing lines                     
            for i in range(0, 600, 60):
                arcade.draw_line(0, i, 600, i, arcade.color.WHITE, 2)

            for i in range(0, 660, 60):
                arcade.draw_line(i, 0, i, 600, arcade.color.WHITE, 2)
            #checking where to have snails and their splashes
            x = 0
            y = 540
            for i in range(10):
                for j in range(10):
                    if self.board[i][j] == 1:
                        arcade.draw_lrwh_rectangle_textured(
                            x, y, 60, 60, splash1)
                    elif self.board[i][j] == 2:
                        arcade.draw_lrwh_rectangle_textured(
                            x, y, 60, 60, splash2)
                    elif self.board[i][j] == 10:
                        arcade.draw_lrwh_rectangle_textured(
                            x, y, 60, 60, cross)
                    elif self.board[i][j] == 20:
                        arcade.draw_lrwh_rectangle_textured(
                            x, y, 60, 60, circle)
                    x = x+60
                x = 0
                y = y-60
                #win condition  
           
        #changing game state
        elif self.state == "GameOver":
            if self.win == "Player_2" :
                arcade.draw_text("Congratulations! You Won",
                                 400, 450, arcade.color.RAJAH, font_size=40, anchor_x="center")
                arcade.draw_lrwh_rectangle_textured(270, 140, 250, 300, winner)
                arcade.draw_text("Press 'ENTER' to play again",
                                    400, 100, arcade.color.RAJAH, font_size=40, anchor_x="center")
            elif self.win == "Player_1" :
                arcade.draw_text("Ooops! You Lose",
                                 400, 450, arcade.color.RAJAH, font_size=40, anchor_x="center")
                arcade.draw_lrwh_rectangle_textured(270, 160, 300, 250, lose)
                arcade.draw_text("Press 'ENTER' to play again",
                                    400, 100, arcade.color.RAJAH, font_size=40, anchor_x="center")
            else:
                arcade.draw_text("DRAW",
                                 400, 300, arcade.color.RAJAH, font_size=40, anchor_x="center")
                arcade.draw_text("Press 'ENTER' to play again",
                                    400, 100, arcade.color.RAJAH, font_size=40, anchor_x="center")
        

    def heuristic(self):
        winning_chances = 0
        boxes_covered = 0
        old_pos_x = 0
        old_pos_y = 0
        f=0
        b=0
        d=0
        u=0

        for i in range(10):#loop for finding snail position
            for j in range(10):
                if self.temp_board[i][j] == 10:
                    old_pos_x = i
                    old_pos_y = j
                    break
        
        # Boxes Covered
        for i in range(10):
            for j in range(10):
                if self.temp_board[i][j] == 1:
                    boxes_covered += 1
        
        winning_chances += boxes_covered


        # Max num of zeroes
        for i in range(old_pos_y, 9, 1):   
            if self.temp_board[old_pos_x][i+1] == 0:
                f += 1
            else:
                break
        
        for i in range(old_pos_y, 0, -1):
            if self.temp_board[old_pos_x][i-1] == 0:
                b += 1
            else:
                break

        for i in range(old_pos_x, 9, 1):
            if self.temp_board[i+1][old_pos_y] == 0:
                d += 1
            else:
                break

        for i in range(old_pos_x, 0, -1):
           
            if self.temp_board[i-1][old_pos_y] == 0:  
                u += 1
            else:
                break
        
        maximum = max(f,b,d,u)
        winning_chances += maximum
        
        # Centre
        minrange = (len(self.temp_board)/2)-2
        maxrange = (len(self.temp_board)/2)+3

        if minrange <= old_pos_x <= maxrange and minrange <= old_pos_y <= maxrange:
            winning_chances += 10
            
        return winning_chances
    
    def botmove(self):
        if self.turn == "bot":
            slip_x_old=0
            slip_y_old=0
            forward_score=0
            back_score=0
            up_score=0
            down_score=0
            max_score=0
            empty = 0
            for i in range(9, -1, -1):#loop for finding snail position
                for j in range(10):
                    if self.board[i][j] == 10:
                        slip_x_old=i
                        slip_y_old=j
                        break

            self.temp_board = self.board

            # Bot Move
            if slip_x_old+1<10 and self.temp_board[slip_x_old+1][slip_y_old] == 0:
                self.temp_board[slip_x_old+1][slip_y_old] = 10 
                self.temp_board[slip_x_old][slip_y_old] = 1
                down_score = self.heuristic()
                # self.temp_board=self.board
                self.temp_board[slip_x_old+1][slip_y_old] = 0
                self.temp_board[slip_x_old][slip_y_old] = 10
                empty = 1
            if slip_x_old-1>-1 and self.temp_board[slip_x_old-1][slip_y_old] == 0:
                self.temp_board[slip_x_old-1][slip_y_old] = 10 
                self.temp_board[slip_x_old][slip_y_old] = 1
                up_score = self.heuristic()
                # self.temp_board=self.board
                self.temp_board[slip_x_old-1][slip_y_old] = 0
                self.temp_board[slip_x_old][slip_y_old] = 10
                empty = 1
            if slip_y_old+1<10 and self.temp_board[slip_x_old][slip_y_old+1] == 0:
                self.temp_board[slip_x_old][slip_y_old+1] = 10 
                self.temp_board[slip_x_old][slip_y_old] = 1
                forward_score = self.heuristic()
                # self.temp_board=self.board
                self.temp_board[slip_x_old][slip_y_old+1] = 0
                self.temp_board[slip_x_old][slip_y_old] = 10
                empty = 1
            if slip_y_old-1>-1 and self.temp_board[slip_x_old][slip_y_old-1] == 0:
                self.temp_board[slip_x_old][slip_y_old-1] = 10 
                self.temp_board[slip_x_old][slip_y_old] = 1
                back_score = self.heuristic()
                # self.temp_board=self.board
                self.temp_board[slip_x_old][slip_y_old-1] = 0
                self.temp_board[slip_x_old][slip_y_old] = 10
                empty = 1
            max_score = max(forward_score,back_score,down_score,up_score)
          
            if empty==1:
                if max_score==forward_score:
                    self.board[slip_x_old][slip_y_old+1] = 10 
                    self.board[slip_x_old][slip_y_old] = 1
                    self.score_2 += 1
                    self.turn = "Human"
                    self.stop = 0
                elif max_score==back_score:
                    self.board[slip_x_old][slip_y_old-1] = 10 
                    self.board[slip_x_old][slip_y_old] = 1
                    self.score_2 += 1
                    self.turn = "Human"
                    self.stop = 0
                elif max_score==down_score:
                    self.board[slip_x_old+1][slip_y_old] = 10 
                    self.board[slip_x_old][slip_y_old] = 1
                    self.score_2 += 1
                    self.turn = "Human"
                    self.stop = 0
                elif max_score==up_score:
                    self.board[slip_x_old-1][slip_y_old] = 10 
                    self.board[slip_x_old][slip_y_old] = 1
                    self.score_2 += 1
                    self.turn = "Human"
                    self.stop = 0

                

            # slip conditions
            if empty == 0:
                forwrd = 0
                back = 0
                up = 0
                down = 0
                check_x = slip_x_old
                check_y = slip_y_old
                # Checking which side we have most empty boxes
                for i in range(slip_y_old,9):    
                    if self.board[check_x][check_y+1]==1:
                        pass
                    elif self.board[check_x][check_y+1]==0:
                        forwrd = forwrd+1
                    else:
                        break
                    check_y=check_y+1

                check_x = slip_x_old
                check_y = slip_y_old
                for i in range(slip_y_old,0,-1):
                    if self.board[check_x][check_y-1]==1:
                        pass
                    elif self.board[check_x][check_y-1]==0:
                        back = back+1
                    else:
                        break
                    check_y=check_y-1

                check_x = slip_x_old
                check_y = slip_y_old
                print(slip_x_old,slip_y_old)
                for i in range(slip_x_old,9,1):
                    print(i)
                    if self.board[check_x+1][check_y]==1:
                        pass
                    elif self.board[check_x+1][check_y]==0:
                        down = down+1
                    else:
                        break
                    check_x=check_x+1

                check_x = slip_x_old
                check_y = slip_y_old
                for i in range(slip_x_old,0,-1):
                    if self.board[check_x-1][check_y]==1:
                        pass
                    elif self.board[check_x-1][check_y]==0:    
                        up = up+1
                    else:
                        break
                    check_x=check_x-1

                print(forwrd,back,down,up)

                # Slips

                # forward Slip
                if forwrd>back and forwrd>down and forwrd>up:
                    slip_y_new = slip_y_old+1
                    for i in range(9-slip_y_old):
                        if self.board[slip_x_old][slip_y_new]==1:
                            pass
                        else:
                            break
                        slip_y_new=slip_y_new+1   
                    self.board[slip_x_old][slip_y_new-1]=10
                    self.board[slip_x_old][slip_y_old]=1
                    self.turn = "Human"
                    self.stop += 1
                    return              
                
                # back slip

                elif back>forwrd and back>down and back>up:
                    slip_y_new = slip_y_old-1
                    for i in range(slip_y_old+1):
                        if self.board[slip_x_old][slip_y_new]==1:
                            pass
                        else:
                            break
                        slip_y_new=slip_y_new-1   
                    self.board[slip_x_old][slip_y_new+1]=10
                    self.board[slip_x_old][slip_y_old]=1
                    self.turn = "Human"
                    self.stop += 1
                    return
                
                # down slip
                elif down>forwrd and down>back and down>up:
                    slip_x_new = slip_x_old+1
                    for i in range(9-slip_x_old):
                        if self.board[slip_x_new][slip_y_old]==1:
                            pass
                        else:
                            break
                        slip_x_new=slip_x_new+1   
                    self.board[slip_x_new-1][slip_y_old]=10
                    self.board[slip_x_old][slip_y_old]=1
                    self.turn = "Human"
                    self.stop += 1
                    return

                # up slip
                elif up>forwrd and up>back and up>down:
                    slip_x_new = slip_x_old-1
                    for i in range(slip_x_old+1):
                        if self.board[slip_x_new][slip_y_old]==1:
                            pass
                        else:
                            break
                        slip_x_new=slip_x_new-1   
                    self.board[slip_x_new+1][slip_y_old]=10
                    self.board[slip_x_old][slip_y_old]=1
                    self.turn = "Human"
                    self.stop += 1
                    return

                else:
                    
                    if slip_y_old+1<9 and self.board[slip_x_old][slip_y_old+1]==1:
                        slip_y_new = slip_y_old+1
                        for i in range(9-slip_y_old):
                            if self.board[slip_x_old][slip_y_new]==1:
                                pass
                            else:
                                break
                            slip_y_new=slip_y_new+1   
                        self.board[slip_x_old][slip_y_new-1]=10
                        self.board[slip_x_old][slip_y_old]=1
                        self.turn = "Human"
                        self.stop += 1
                        return


                    elif slip_x_old+1<9 and self.board[slip_x_old+1][slip_y_old]==1:
                        slip_x_new = slip_x_old+1
                        for i in range(9-slip_x_old):
                            if self.board[slip_x_new][slip_y_old]==1:
                                pass
                            else:
                                break
                            slip_x_new=slip_x_new+1   
                        self.board[slip_x_new-1][slip_y_old]=10
                        self.board[slip_x_old][slip_y_old]=1
                        self.turn = "Human"
                        self.stop += 1
                        return

                    elif slip_y_old-1>-1 and self.board[slip_x_old][slip_y_old-1]==1:
                        slip_y_new = slip_y_old-1
                        for i in range(slip_y_old+1):
                            if self.board[slip_x_old][slip_y_new]==1:
                                pass
                            else:
                                break
                            slip_y_new=slip_y_new-1   
                        self.board[slip_x_old][slip_y_new+1]=10
                        self.board[slip_x_old][slip_y_old]=1
                        self.turn = "Human"
                        self.stop += 1
                        return

                    elif slip_x_old-1>-1 and self.board[slip_x_old-1][slip_y_old]==1:
                        slip_x_new = slip_x_old-1
                        for i in range(slip_x_old+1):
                            if self.board[slip_x_new][slip_y_old]==1:
                                pass
                            else:
                                break
                            slip_x_new=slip_x_new-1   
                        self.board[slip_x_new+1][slip_y_old]=10
                        self.board[slip_x_old][slip_y_old]=1
                        self.turn = "Human"
                        self.stop += 1
                        return

                             
                    
                    

                    
    def EvalBoard(self):
        
        if self.score_1>49:
            self.win = "Player_2"
            self.state = "GameOver"
        elif self.score_2>49:
            self.win = "Player_1"
            self.state = "GameOver"

        try:#try block to check Draw stage
            win = 0
            for i in range(10):
                for j in range(10):
                    if self.board[i][j] == 0:
                        win = 1
                        break
            if win == 0 and self.score_1==self.score_2:
                self.win = "Draw"
                self.state = "GameOver"
        except Exception:
            pass

        if self.stop > 9:
            if self.score_1>self.score_2:
                self.win = "Player_2"
                self.state = "GameOver"
            elif self.score_2>self.score_1:
                self.win = "Player_1"
                self.state = "GameOver"

    def on_mouse_press(self, x, y, _button, _modifiers):
        if self.state == "GameOn":
            if self.turn == "Human":
                    Sum = 0
                    Row_num = 0
                    col_num = 0
                    check_variable = 0
                    for i in range(9, -1, -1):# finding snail position
                        for j in range(10):
                            if self.board[i][j] == 20:
                                slip_x_old=i
                                slip_y_old=j
                                break
                    try:  # restricting user 
                        x1 = 0
                        x2 = 60
                        y1 = 0
                        y2 = 60
                        for i in range(9, -1, -1):
                            for j in range(10):
                                if x1 <= x <= x2 and y1 <= y <= y2:
                                    
                                    if self.board[i][j] == 20:	                                    
                                        check_variable += 1
                                    elif self.board[i][j] == 2:#checking if user clicks on his own track.....
                                        check_variable = 11    
                                        slip_x_new=i
                                        slip_y_new=j
                                    elif self.board[i][j] != 0:
                                        check_variable += 1
                                    elif self.board[i][j] == 0:
                                        check_r = j
                                        check_c = i
                                        check_sum = i+j
                                x1 = x2
                                x2 = x2+60
                            y1 = y2
                            y2 = y2+60
                            x1 = 0
                            x2 = 60
                    except Exception:
                        pass
                    if check_variable == 0:  # if he clicks on empty block update frontend and board
                        for i in range(9, -1, -1):
                            for j in range(10):
                                if self.board[i][j] == 20:
                                    Sum = i+j
                                    Row_num = j
                                    col_num = i
                                    # if he do not  clicks on adjacent blocks ,turn lost
                                    if j-check_r > 1 or j-check_r < -1:
                                        self.turn = "bot"
                                        print("step1")
                                        return
                                    elif i-check_c < -1 or i-check_c > 1:
                                        self.turn = "bot" 
                                        print("step1")  
                                        return
                                    # if he clicks on adjacent blocks  update backend array and frontend  
                                    elif j-check_r == 1 or j-check_r == -1:
                                        if i-check_c == 0:
                                            # if Sum-check_sum == 1 or Sum-check_sum == -1:
                                                self.board[i][j] = 2
                                    elif i-check_c == -1 or i-check_c == 1:
                                        if j-check_r == 0:
                                            # if Sum-check_sum == 1 or Sum-check_sum == -1:
                                                self.board[i][j] = 2
                    #slip Conditions                            
                    elif check_variable==11:
                        if slip_x_old==slip_x_new and slip_y_new==slip_y_old+1:#forward slip
                            for i in range(9-slip_y_old):
                                if self.board[slip_x_old][slip_y_new]==2:
                                    pass
                                else:
                                    break
                                slip_y_new=slip_y_new+1   
                            self.board[slip_x_old][slip_y_new-1]=20
                            self.board[slip_x_old][slip_y_old]=2
                            self.turn = "bot"
                            self.stop += 1 
                            return
                        elif slip_x_old==slip_x_new and slip_y_new==slip_y_old-1:#backward slip
                            for i in range(slip_y_old+1):
                                if self.board[slip_x_old][slip_y_new]==2:
                                    pass
                                else:
                                    break
                                slip_y_new=slip_y_new-1   
                            self.board[slip_x_old][slip_y_new+1]=20
                            self.board[slip_x_old][slip_y_old]=2
                            self.turn = "bot"
                            self.stop += 1
                            return
                            
                        elif slip_y_old==slip_y_new and slip_x_new==slip_x_old+1:#downward slip
                            for i in range(9-slip_x_old):
                                if self.board[slip_x_new][slip_y_old]==2:
                                    pass
                                else:
                                    break
                                slip_x_new=slip_x_new+1   
                            self.board[slip_x_new-1][slip_y_old]=20
                            self.board[slip_x_old][slip_y_old]=2
                            self.turn = "bot"
                            self.stop += 1
                            return
                        elif slip_y_old==slip_y_new and slip_x_new==slip_x_old-1:#upward slip
                            for i in range(slip_x_old+1):
                                if self.board[slip_x_new][slip_y_old]==2:
                                    pass
                                else:
                                    break
                                slip_x_new=slip_x_new-1   
                            self.board[slip_x_new+1][slip_y_old]=20
                            self.board[slip_x_old][slip_y_old]=2
                            self.turn = "bot"
                            self.stop += 1
                            return
                        else:#otherwise he will lose turn
                            self.turn = "bot"
                            self.stop += 1
                            return
                    try:#block if players do a valid move update frontend and backend array as well
                        x1 = 0
                        x2 = 60
                        y1 = 0
                        y2 = 60
                        for i in range(9, -1, -1):
                            for j in range(10):
                                if x1 <= x <= x2 and y1 <= y <= y2:
                                    if self.board[i][j] == 0:
                                        if Sum == (i+j)+1 or Sum == (i+j)-1:
                                            if Row_num+1 == j or Row_num-1 == j:
                                                if col_num == i:
                                                    self.board[i][j] = 20
                                                    self.score_1 = self.score_1+1#update score
                                                    self.stop = 0
                                            elif col_num-1 == i or col_num+1 == i:
                                                if Row_num == j:
                                                    self.board[i][j] = 20
                                                    self.score_1 = self.score_1+1#update score
                                                    self.stop=0

                                            else:
                                                raise Exception
                                        else:
                                            raise Exception
                                    else:
                                        raise Exception
                                x1 = x2
                                x2 = x2+60
                            y1 = y2
                            y2 = y2+60
                            x1 = 0
                            x2 = 60
                        #change turn
                        print("Turning to bot")  
                        self.turn ="bot"
                    except Exception:
                        pass
            self.EvalBoard()
            self.botmove() 
            self.EvalBoard()          
            
if __name__ == "__main__":#main function
    window = arcade.Window(800, 600, "Tic Tac Toe")
    game_view = Game()
    window.show_view(game_view)
    arcade.run()